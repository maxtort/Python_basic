import zipfile
import os


def create_zip(zip_filename, file_to_zip):
    with zipfile.ZipFile(zip_filename, 'w') as zipf:
        for file in file_to_zip:
            if os.path.isfile(file):
                zipf.write(file, arcname=os.path.basename(file))


file_to_zip = ['groups.py', 'main.py', 'users.py', 'create_zip.py']
create_zip('lesson_14.zip', file_to_zip)